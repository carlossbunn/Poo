import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        String temp = new String();//antes era null e o texto.toCharArray() não aceita de tal forma
        Scanner s = new Scanner(System.in);
        temp = s.next();
        temp = Inversor.inverterString(temp);
        System.out.println(temp);
    }

}
/*inconsistencias no codigo: texto.toCharArray() não aceita "null"
criei um objeto do tipo String para solucionar e  no "[]invertido" não se coloca o -2


a) com as resoluções feitas, quando chamado
  1)ele cria dois char's e cria um index para com o tamanho de "[] letras"
  2)é colocado num de tamanho de "letras" onde a criação do "invertido"
    começa pelo ultimo caracter de "letras" pois o index faz chegar até lá
    seguindo a seguinte ideia
     letras [a, b, c, d]         letras [a, b, c, d]
                      /                        /
  index letras.lenght -1   -->   index letras.lenght -1
            \                                \
   invertido[d,...]              invertido[d, c,...]
até o final da string

b) com as resoluções feitas
 a string de saida é "rosseforp"

 */