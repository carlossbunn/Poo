public class Ponto3D extends Ponto2D{
    private double z;
    
    Ponto3D(double x, double y, double z){
        x=_x;
        x=_y;
        x=_z;
    }
}
