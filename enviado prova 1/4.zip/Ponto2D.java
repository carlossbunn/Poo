public class Ponto2D {
    private double x,y;

    Ponto2D (double _x,double _y){
        x= _x;y=_y;
    }
}
/*1) Espaço na criação do metodo "ponto 2D" não se encaixa sintaxe do JAVA
   o correto seria "Ponto2D".
2) Na classe Ponto3D precisa ser iniciadas
   sendo as variais _x,_y,_z não estao inciadas de forma certa.
2.2) falta o super na herança*/